package com.nethsara.aiplayer

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

 data class SubtitleCue(val startMs: Long, val endMs: Long, val text: String)

class MainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var subtitleOverlay: TextView
    private lateinit var title: TextView
    private lateinit var status: TextView
    private val videoUris = mutableListOf<Uri>()
    private var cues: List<SubtitleCue> = emptyList()
    private val handler = Handler(Looper.getMainLooper())
    private val subtitleTicker = object : Runnable {
        override fun run() {
            val pos = player?.currentPosition ?: 0L
            val cue = cues.firstOrNull { pos >= it.startMs && pos <= it.endMs }
            subtitleOverlay.text = cue?.text.orEmpty()
            handler.postDelayed(this, 120)
        }
    }

    private val pickVideos = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                if (!videoUris.contains(uri)) videoUris.add(uri)
            }
            showLibrary(); play(videoUris.last())
        }
    }
    private val pickOneVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            if (!videoUris.contains(uri)) videoUris.add(uri)
            showLibrary(); play(uri)
        }
    }
    private val pickSrt = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadSrt(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        player?.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                status.text = if (isPlaying) "වීඩියෝව ධාවනය වේ" else "විරාම කර ඇත"
            }
        })
        status.text = "වීඩියෝවක් තෝරන්න. පසුව SRT උපසිරැසි ගොනුවක් එක් කළ හැකියි."
        handler.post(subtitleTicker)
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 12); setBackgroundColor(0xFF08111F.toInt())
        }
        title = TextView(this).apply { text = "NETHSARA AI PLAYER"; textSize = 22f; setTextColor(0xFF40D8E8.toInt()); setPadding(0, 8, 0, 4) }
        status = TextView(this).apply { textSize = 13f; setTextColor(0xFFB8C7D9.toInt()); setPadding(0, 4, 0, 10) }
        root.addView(title); root.addView(status)
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(makeButton("වීඩියෝ එකතු කරන්න") { pickVideos.launch(arrayOf("video/*", "video/x-matroska", "application/x-matroska")) }, weight())
        row1.addView(makeButton("එකක් විවෘත කරන්න") { pickOneVideo.launch(arrayOf("video/*", "video/x-matroska", "application/x-matroska")) }, weight())
        root.addView(row1)
        val videoFrame = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 10; bottomMargin = 10 } }
        playerView = PlayerView(this).apply { useController = true; layoutParams = FrameLayout.LayoutParams(-1, -1) }
        subtitleOverlay = TextView(this).apply {
            textSize = 19f; gravity = Gravity.CENTER; setTextColor(0xFFFFFFFF.toInt()); setPadding(12, 8, 12, 8)
            setShadowLayer(5f, 2f, 2f, 0xFF000000.toInt()); setBackgroundColor(0x66000000)
            layoutParams = FrameLayout.LayoutParams(-1, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { setMargins(18, 0, 18, 58) }
        }
        videoFrame.addView(playerView); videoFrame.addView(subtitleOverlay); root.addView(videoFrame)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(makeButton("SRT උපසිරැසි එක් කරන්න") { pickSrt.launch(arrayOf("application/x-subrip", "text/plain", "application/octet-stream")) }, weight())
        row2.addView(makeButton("උපසිරැසි ඉවත් කරන්න") { cues = emptyList(); subtitleOverlay.text = ""; status.text = "උපසිරැසි ඉවත් කළා" }, weight())
        root.addView(row2)
        root.addView(makeButton("AI සිංහල උපසිරැසි නිර්මාණය — ඉදිරියේදී") {
            Toast.makeText(this, "Offline speech recognition සහ Sinhala translation model එක තවම සම්බන්ධ කර නැහැ. මේ Version එකේ SRT import/display පමණක් ක්‍රියාත්මකයි.", Toast.LENGTH_LONG).show()
        })
        root.addView(makeButton("මගේ වීඩියෝ ලැයිස්තුව") { showLibrary() })
        setContentView(root)
    }

    private fun weight() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } }

    private fun play(uri: Uri) {
        player?.setMediaItem(MediaItem.fromUri(uri)); player?.prepare(); player?.play()
        title.text = "NETHSARA AI PLAYER"; status.text = "ධාවනය: ${uri.lastPathSegment ?: "වීඩියෝව"}"
    }

    private fun loadSrt(uri: Uri) {
        try {
            val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            cues = parseSrt(raw)
            status.text = "SRT උපසිරැසි ${cues.size}ක් පූරණය කළා"
            Toast.makeText(this, "උපසිරැසි ${cues.size}ක් එක් කළා", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "SRT ගොනුව කියවීමට නොහැකි වුණා", Toast.LENGTH_LONG).show()
        }
    }

    private fun parseSrt(raw: String): List<SubtitleCue> {
        val normalized = raw.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
        return normalized.trim().split(Regex("\\n\\s*\\n")).mapNotNull { block ->
            val lines = block.lines().filter { it.isNotBlank() }
            val timeLine = lines.firstOrNull { it.contains("-->") } ?: return@mapNotNull null
            val parts = timeLine.split("-->")
            if (parts.size != 2) return@mapNotNull null
            val start = parseTime(parts[0].trim()) ?: return@mapNotNull null
            val end = parseTime(parts[1].trim().substringBefore(' ').trim()) ?: return@mapNotNull null
            val idx = lines.indexOf(timeLine)
            val text = lines.drop(idx + 1).joinToString("\n").trim()
            if (text.isEmpty() || end <= start) null else SubtitleCue(start, end, text)
        }.sortedBy { it.startMs }
    }

    private fun parseTime(value: String): Long? {
        return try {
            val p = value.replace(',', '.').split(':')
            if (p.size != 3) null else {
                val seconds = p[2].toDouble()
                ((p[0].toLong() * 3600 + p[1].toLong() * 60) * 1000 + (seconds * 1000).toLong())
            }
        } catch (_: Exception) { null }
    }

    private fun showLibrary() {
        val names = videoUris.mapIndexed { i, uri -> "${i + 1}. ${uri.lastPathSegment ?: uri}" }
        android.app.AlertDialog.Builder(this).setTitle("වීඩියෝ ලැයිස්තුව (${videoUris.size})")
            .setItems(names.toTypedArray()) { _, which -> play(videoUris[which]) }
            .setNegativeButton("වසන්න", null).show()
    }

    override fun onDestroy() {
        handler.removeCallbacks(subtitleTicker); playerView.player = null; player?.release(); player = null
        super.onDestroy()
    }
}
