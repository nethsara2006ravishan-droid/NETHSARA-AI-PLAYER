# NETHSARA AI PLAYER — Subtitle Prototype v1

මෙය Android Studio source project එකකි. APK එකක් නොවේ.

## මේ Version එකේ ක්‍රියාත්මක දේ
- Android file picker එකෙන් MP4 සහ සහාය දක්වන වෙනත් video files විවෘත කිරීම.
- Media3 / ExoPlayer මඟින් video play, pause සහ seek කිරීම.
- `.srt` subtitle file එකක් තෝරාගෙන video එකට ගැළපෙන වේලාවට screen එකේ පෙන්වීම.
- SRT subtitle ඉවත් කිරීම.

## තවම ක්‍රියාත්මක නොවන දේ
**AI Sinhala subtitle generation එක මේ prototype එකට තවම සම්බන්ධ කර නැහැ.** AI බොත්තම placeholder එකක් පමණයි. Offline ASR model, Sinhala translation model, model download/installation සහ native inference pipeline එක වෙනම සම්බන්ධ කළ යුතුයි. ඒවා නොමැතිව app එක AI subtitles හදනවා කියා නොකියයි.

## Build
- Android Studio
- JDK 17
- Gradle plugin 8.7.3
- Project එක Android Studio තුළ open කර Gradle Sync කර Run කරන්න.

## සටහන
Whisper වැනි offline speech recognition model එකක් Android වෙත එකතු කිරීම සඳහා model file එක සහ native runtime අවශ්‍ය වේ. Sinhala transcript එකක් ලැබීම සහ එය ස්වභාවික Sinhala බවට පරිවර්තනය කිරීම වෙනම පියවර දෙකකි. මෙම prototype එකේ ඒවා තවම නැත.
